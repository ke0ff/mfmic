/********************************************************************
 ************ COPYRIGHT (c) 2022 by ke0ff, Taylor, TX   *************
 *
 *  File name: hm_cmds.c
 *
 *  Module:    Control
 *
 *  Summary:   This is the hm_cmd processing module for the MFmic RDU target
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *    09-17-22 jmh:  creation date
 *
 *******************************************************************/

#include <driver_init.h>
#include <compiler.h>
#include <avr/io.h>
#include "hm_cmds.h"
#include "main.h"
#include "nvmctrl.h"
#include "serial.h"

//=================================
// local defines
//=================================

// MFmic HM-key state machine defines
#define	HMST_IDLE		1			// initial state
#define	HMST_PRESSD		2			// pressed state: "h" or "r/R" to exit
#define	HMST_HOLD		3			// hold state: "r/R" to exit
#define	HMST_REL		4			// release debounce

//=================================
// file-scope variable declarations
//=================================

// HM-133 MFmic support
uint8_t	hm_buf[HM_BUFF_END];				// signal buffer
uint8_t	hm_hptr;
uint8_t	hm_tptr;
char	msg_buf[MSG_BUFF_END];				// uart signal buffer
uint8_t	shftm;								// fn-shift mem register (MFmic)
uint8_t	backl_level;						// backlight bright level index
#define MAX_LEVEL	10
// PWM brightness table
uint8_t	level_table[MAX_LEVEL] = { 0, 1, 2, 5, 10, 25, 45, 65, 85, 99 };

#define EEPAGE0			(EEPROM_START)
#define EEPAGE1			(EEPROM_START + EEPROM_PAGE_SIZE)
#define EE_DIM			(EEPROM_START + EEPROM_PAGE_SIZE + 1)
#define EE_BRT			(EEPROM_START + EEPROM_PAGE_SIZE + 2)
#define EE_PTSMODE_BNK0	(EEPROM_START + EEPROM_PAGE_SIZE + 3)
#define EE_PTSMODE_BNK1	(EEPROM_START + EEPROM_PAGE_SIZE + 4)
#define EE_PTSMODE_BNK2	(EEPROM_START + EEPROM_PAGE_SIZE + 5)
#define EE_PTSMODE_BNK3	(EEPROM_START + EEPROM_PAGE_SIZE + 6)

//=================================
// file-scope fn declarations
//=================================

void hm_map(uint8_t cm, uint8_t hm);
uint8_t set_shift(uint8_t tf);
void hm_sto(uint8_t j);
uint8_t* get_eeptr(void);

//=================================
// source code
//=================================

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// hm_cmd_get() processes the hm command intercept and fills the hm_buf[]
//	with keypress actions from the MFmic interface.  This stream is then processed
//	to actuate the keypress signals.
//	This gets called once for each MFmic key packet received.  MFmic packets
//	all start with '~'.  Valid packets have the following:
//		pcskz
//		p = '~'
//		c = command chr
//		s = status chr
//		k = check = (c ^ s) | 0x80
//		z = \r (carriage return) (this is stripped by the cmd-ln pre-processing
//			 and thus becomes a '\0' character)
//		'p', 'c', and 's' are printable ASCII. 'k' is made to be a non-ASCII character
//			by virtue of the hi-bit being set.  Setting the hi-bit also guarantees
//			that the check won't ever be a null, allowing standard null-terminated
//			array handling to be valid.
//		sptr = pointer to input cmd string
//		pcmd = 0xff to init statics, else 0
//
// If the message is valid, the Key and cmd (pressed, hold, or released) are extracted
//	and passed up to the execution point.
//-----------------------------------------------------------------------------
void hm_cmd_get(char* sptr, uint8_t pcmd){
		uint8_t	cm;				// extracted command
		uint8_t	hm;				// extracted press/hold/release status
		uint8_t	j;				// temp
static	uint8_t	hm_state;		// state machine process variable
static	uint8_t	cm_last;		// last cmd

	// IPL init of statics
	if(pcmd == 0xff){
		shftm = 0;
		hm_state = HMST_IDLE;
		cm_last = '\0';
		return;
	}
	j = (*(sptr+1) ^ *(sptr+2)) | 0x80;
	// if command packet valid, process state machine
	if((j == *(sptr+3)) && (*(sptr+4) == '\0') && (*sptr == HMKEY_CMD)){
		// capture command and press/hold/release status from the packet payload
		cm = *(sptr+1);
		hm = *(sptr+2);
		// state machine to process key press-hold-release sequence
		switch(hm_state){
		default:
		case HMST_IDLE:
			// look for a press or hold (if we see a hold here, we assume that the press packet was missed)
			if((hm == 'p') || (hm == 'h')){
				hm_map(cm, 'p');					// map initial keypress into signal buffer
				hm_state = HMST_PRESSD;				// point to next state
				chk_tmr5(HM_HOLD_TIME);				// start hold timer (the same hold delay time as for the panel buttons)
				cm_last = cm;						// save the command.  Us this saved value for subsequent actions until release
			}
			break;

		case HMST_PRESSD:
			// At this point in the process, hold or release is expected
			// a press is assumed to be a repeat press packet and is ignored
			switch(hm){
			case 'R':
			case 'r':
				hm_map(cm_last, 'r');				// map release into signal buffer
				hm_state = HMST_IDLE;				// return to start
				break;

			case 'h':
				if(!chk_tmr5(0)){					// if "hold" is indicated AND there is a timeout:
					hm_map(cm_last, hm);			// map hold keypress into signal buffer
					hm_state = HMST_HOLD;			// point to next state
					chk_tmr5(HM_HOLD_TIME);			// reset hold timer
				}
				break;

			default:
				break;
			}
			break;

		case HMST_HOLD:
			// if there is a timeout of the hmk_timer, we assume a critical loss and force the keypress to be released
			if(!chk_tmr5(0)){
				hm = 'r';							// timeout, force release
			}
			// once the hold mode is encountered, we look for release or a timeout (loss of comms from the MFmic).
			switch(hm){
			default:
				break;

			case 'h':								// a valid hold packet resets the timeout
				chk_tmr5(HM_HOLD_TIME);
				break;

			case 'R':								// valid release
			case 'r':
				hm_map(cm_last, 'r');				// map release keypress into signal buffer
				hm_state = HMST_IDLE;				// point to next state
				cm_last = '\0';						// clear cmd mem
				break;

			// a press here is an error.  Assume that the release of the previous key was lost & start a new press sequence
			case 'p':
				// process the release of the previous key
				hm_map(cm_last, 'r');				// map release keypress into signal buffer
				// start a new press
				hm_map(cm, 'p');					// map keypress into signal buffer
				hm_state = HMST_PRESSD;				// point to next state
				chk_tmr5(HM_HOLD_TIME);				// start hold timer
				cm_last = cm;						// set cmd mem
				break;
			}
			break;
		}
	}
	return;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// hm_map() maps the MFmic hm command intercept to a local key ID and fills the hm_buf[]
//	cm = key code (ASCII, maps to keypad on HM-133 interface)
//	hm = (p)ress/(h)old/(r)elease
//-----------------------------------------------------------------------------
//char keychr_lut[] = {  TSchr, };
void hm_map(uint8_t cm, uint8_t hm){
volatile	uint8_t	j = '\0';		// temps
//static		uint8_t	pfx_button;		// holds last cmd button pressed for prefix parameter processing

	// trap null inputs
	if((cm == '\0') || (hm == '\0')){
		return;
	}
	if(hm == 'R') hm = 'r';					// only use 'r' from here on...
	if(!shftm){
		switch(cm){
		default:
			break;

		case F1KEY:
		case F2KEY:
		case SH_UPKEY:
		case SH_DNKEY:
		case SH_CALLKEY:
		case SH_VMKEY:
		case SH_MWKEY:
		case SH_F2KEY:
		case SH_XFCKEY:
		case SH_0:
		case SH_1:
		case SH_2:
		case SH_3:
		case SH_4:
		case SH_5:
		case SH_6:
		case SH_7:
		case SH_8:
		case SH_9:
		case SH_STR:
		case SH_PND:
		case SH_A:
		case SH_B:
		case SH_C:
		case SH_D:
			set_shift(1);
			break;
		}
	}
	// map keys with shift mode active
	if(shftm == 1){
		chk_tmr6(HM_SHFTIM);		// kick the shift timer
		switch(cm){
			default:
				break;
				
			case F1KEY:
				j = DMA_NOKEY;
				if(hm == 'p'){
					do_beep_err(1);
				}
				break;

			case SH_F2KEY:
			case F2KEY:
				if(hm == 'p'){
					do_beep(2);			// HM-151 FUNC key telemetry
				}
				j = DMA_NOKEY;
				break;

			case LOKEY:
			case SH_LOKEY:			// (FUNC-LOCK) == shift-toggle key
				j = DMA_RNULL;		// set RPN reg to invalid
				if(hm == 'p'){
					set_shift(0);
				}
				break;

			case '#':
				j = DMA_CHECK;
				break;

			case SH_DNKEY:
			case '\\':				// mic dn == dial dn
				j = DMA_DIAL_DN;
				if(hm == 'p'){
					do_beep(1);
				}
				break;

			case SH_UPKEY:
			case '/':				// mic up == dial up
				j = DMA_DIAL_UP;
				if(hm == 'p'){
					do_beep(1);
				}
				break;

			case SH_XFCKEY:			// main mute
			case XFCKEY:
				j = DMA_FACI;
				break;

			case SH_VMKEY:
			case VMKEY:
				j = DMA_BANK;
				break;

			case SH_MWKEY:
			case MWKEY:
				j = DMA_MW;
				break;

			case SH_A:
			case 'A':
				j = DMA_SET;
				break;

			case SH_B:
			case 'B':
				j = DMA_TS;
				break;

			case SH_C:
			case 'C':			// mode
				j = DMA_MODE;
				break;

			case SH_D:
			case 'D':
				if(hm == 'h'){
					// main-mute
					j = DMA_MMUTE;
				}else{
					j = DMA_SMUTE;
				}
				break;

			case SH_CALLKEY:
			case CALLKEY:			// pttsub enter
				j = DMA_PSUBENT;
			break;

			case SH_0:			// shifted numbers are for RPN macro cmds
			case SH_1:
			case SH_2:
			case SH_3:
			case SH_4:
			case SH_5:
			case SH_6:
			case SH_7:
			case SH_8:
			case SH_9:
				j = cm - SH_0 + DMA_0;
				if(hm == 'p'){
//					do_beep(1);
				}
				break;

			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				j = cm - '0' + DMA_0;
				if(hm == 'p'){
//					do_beep(1);
				}
				break;

			case '*':
			case SH_STR:
				j = DMA_NOKEY;			// we don't use these here...
				if(hm == 'p'){
					do_beep_err(1);										// invalid -- do error beep
				}

		}
	// map keys in normal mode
	}else{
		switch(cm){
			default:
				j = DMA_NOKEY;
				break;

			case KEY_NULL:			// fault-tolerant key release
				j = DMA_KNULL;
				break;

			case '\\':				// mic dn
				j = DMA_MIC_DN;
				break;

			case '/':				// mic up
				j = DMA_MIC_UP;
				break;

			case VMKEY:
				j = DMA_VM;
				break;

			case XFCKEY:
				j = DMA_MS;
				break;

			case CALLKEY:
				j = DMA_CALL;
				break;

			case MWKEY:
				j = DMA_HL;
				break;

			case F1KEY:
				j = DMA_SUB;
				break;

			case 'D':
				if(hm == 'h'){
					// main-mute
					j = DMA_MMUTE;
				}else{
					j = DMA_SMUTE;
				}
				break;

			case 'C':
				j = DMA_BAND;
				break;

			case 'A':
				j = DMA_VOLUP;
				break;

			case 'B':
				j = DMA_VOLDN;
				break;

			case '0':			// TONE on/off
				j = DMA_TSQ;
				break;

			case '3':
				j = DMA_SQUP;
				break;

			case '6':
				j = DMA_SQDN;
				break;

  			case '2':			// dial up
				j = DMA_DIAL_UP;
				if(hm == 'p'){
					do_beep(1);
				}
				break;

			case '5':			// dial dn
				j = DMA_DIAL_DN;
				if(hm == 'p'){
					do_beep(1);
				}
				break;

			case '1':
				if(hm == 'p'){
					// brt
					backl_level++;
					if(backl_level > (MAX_LEVEL-1)){
						backl_level = MAX_LEVEL - 1;
					}
					set_pwm(level_table[backl_level]);
					do_beep(1);
				}
				if(hm == 'h'){
					// dim save
					backl_level--;
					if(backl_level > MAX_LEVEL) backl_level = 0;
					set_pwm(backl_level);
					brt_level(PGM_EEBRT);
				}
				j = DMA_NOKEY;
				break;

			case '4':
				if(hm == 'p'){
					// dim
					backl_level--;
					if(backl_level > MAX_LEVEL){
						backl_level = 0;
					}
					set_pwm(level_table[backl_level]);
					do_beep(1);
				}
				if(hm == 'h'){
					// dim save
					backl_level++;
					if(backl_level > MAX_LEVEL) backl_level = 0;
					set_pwm(backl_level);
					brt_level(PGM_EEDIM);
				}
				j = DMA_NOKEY;
				break;

/*			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':*/
			case '7':
			case '8':
			case '9':
				j = DMA_NOKEY;			// we don't use these here...
				if(hm == 'p'){
					do_beep_err(1);										// invalid -- do error beep
				}
				break;

			case '#':
				j = DMA_CHECK;
				break;

			case '*':			// tstep
				j = DMA_SUB;
				break;

/*			case F2KEY:
			case SH_LOKEY:
				j = DMA_NOKEY;
				if(hm == 'p'){
					set_shift(1);
					do_beep(2);
				}
				break;*/

			case LOKEY:
				j = DMA_MHZ;
				break;
		}
	}
	// j == mapped key
	if(j){
		switch(hm){
		// process initial press (no change)
		case 'p':
			break;

		// process hold
		case 'h':
			if((j == DMA_DIAL_UP) || (j == DMA_DIAL_DN)){
				j = DMA_TOGP2;
			}else{
				j |= DMA_KHOLD;
			}
			break;

		default:
		case 'r':
			j = DMA_KREL; //|= KREL_FLAG;
			break;
		}
		// store cmd byte to circ buffer
		hm_sto(j);
	}
	return;
} // end key processing

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// set_shift() sets/clears func shift mode
//	returns shftm
//-----------------------------------------------------------------------------
uint8_t set_shift(uint8_t tf){

	if(tf == 1){
		shftm = 1;
		chk_tmr6(HM_SHFTIM);							// start the shift timer
	}
	if(tf == 0){
		shftm = 0;
		do_beep(3);
		chk_tmr6(TIMER_CLEAR);							// clear the shift timer
	}
	return shftm;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// process_CMD() processes the shift timeout
//-----------------------------------------------------------------------------
char process_CMD(uint8_t flag){

	if(flag == PROC_INIT){
		// init file-local statics
		hm_hptr = 0;									// init MFmic head/tail buffer indexes
		hm_tptr = 0;
		chk_tmr6(TIMER_CLEAR);							// clear timeout
		hm_cmd_get(msg_buf, IPL_CMD);
		return 0;
	}
	// process shift timeout -- turn off shift and execute beeps
	if((shftm) && !chk_tmr6(0)){
		set_shift(0);									// un-shift and update DU status
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// got_hm_asc() returns true if there is a MFmic cmd waiting
//-----------------------------------------------------------------------------
uint8_t got_hm_asc(void){
	uint8_t	rtn = '\0';

	if(hm_hptr != hm_tptr){
		rtn = 0xff;										// there is data
	}
	return rtn;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// msg_ptr() returns the pointer to the msg_buffer
//-----------------------------------------------------------------------------
char* msg_ptr(void){

	return msg_buf;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// hm_asc() fetches code characters from the MFmic input stream
//-----------------------------------------------------------------------------
uint8_t hm_asc(void){
	uint8_t	rtn = '\0';

	if(hm_hptr != hm_tptr){
		rtn = hm_buf[hm_tptr++];						// get keypad code
		if(hm_tptr >= HM_BUFF_END){						// update buf ptr w/ roll-over
			hm_tptr = 0;
		}
	}
	return rtn;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// hm_sto() stores kkey code characters to the MFmic input stream
//-----------------------------------------------------------------------------
void hm_sto(uint8_t j){

	// store to circ buffer
	hm_buf[hm_hptr++] = j;
	// Process rollover
	if(hm_hptr >= HM_BUFF_END){
		hm_hptr = 0;
	}
	// Process pointer overflow -- discards oldest entry
	if(hm_hptr == hm_tptr){
		hm_tptr += 1;
		if(hm_tptr >= HM_BUFF_END){
			hm_tptr = 0;
		}
	}
	return;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// brt_level() manages backl_level to/fr eeprom.  If cmd == PGM_EE, the level is stored
//	to EEPROM.  If cmd == READ_EE, the level is read from EEPROM
//	Page 1 is used to store level.
//-----------------------------------------------------------------------------
uint8_t brt_level(uint8_t cmd){

	switch(cmd){
	default:
		break;
	
	case PGM_EEDIM:
		eewr((uint8_t*)(EE_DIM), backl_level);
		break;
	
	case PGM_EEBRT:
		eewr((uint8_t*)(EE_BRT), backl_level);
		break;
	
	case READ_EEDIM:
		backl_level = eerd((uint8_t*)(EE_DIM));
	break;
	
	case READ_EEBRT:
		backl_level = eerd((uint8_t*)(EE_BRT));
	break;
	}
	if(backl_level > MAX_LEVEL) backl_level = MAX_LEVEL/2;
	return level_table[backl_level];
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// sto_psub() saves pttsub mode to EEPROM using current bank setting as index into eeprom array
//-----------------------------------------------------------------------------
void sto_psub(uint8_t mode){

	eewr(get_eeptr(), mode);
	return;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// rd_psub() reads pttsub mode from EEPROM using current bank setting as index into eeprom array
//-----------------------------------------------------------------------------
uint8_t rd_psub(void){

	return eerd(get_eeptr());
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// get_eeptr() returns eeprom pointer
//-----------------------------------------------------------------------------
uint8_t* get_eeptr(void){
	uint8_t		i;		// bank index
	uint8_t*	eeptr;	// eeprom pointer

	i = read_bank();
	switch(i){
		default:
		case 0:
		eeptr = (uint8_t*)EE_PTSMODE_BNK0;
		break;

		case 1:
		eeptr = (uint8_t*)EE_PTSMODE_BNK1;
		break;

		case 2:
		eeptr = (uint8_t*)EE_PTSMODE_BNK2;
		break;
		
		case 3:
		eeptr = (uint8_t*)EE_PTSMODE_BNK3;
		break;
	}
	return eeptr;
}
// end hm_cmds.c