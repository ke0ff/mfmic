/********************************************************************
 ************ COPYRIGHT (c) 2022 by ke0ff, Taylor, TX   *************
 *
 *  File name: serial.c
 *
 *  Module:    Control
 *
 *  Summary:   This is the serial I/O module for the banksw/RDU app
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *    02-20-22 jmh:  creation date
 *
 *******************************************************************/

#include <driver_init.h>
#include <compiler.h>
#include <avr/io.h>
#include "serial.h"
#include "main.h"
#include "hm_cmds.h"

//=================================
// local defines
//=================================

#define RXD_ERR 0x01
#define RXD_BS 0x04					// BS rcvd flag
#define RXD_ESC 0x40				// ESC rcvd flag
#define RXD_CHAR 0x80				// CHAR rcvd flag (not used)
#define RXD_BUFF_END 40

//=================================
// file-scope variable declarations
//=================================

char	rxd_buff[RXD_BUFF_END];		// rx data buffer
uint8_t	rxd_hptr;					// rx buf head ptr = next available buffer input
uint8_t	rxd_tptr;					// rx buf tail ptr = next available buffer output
uint8_t	rxd_stat;					// rx buff status
uint8_t	rxd_crcnt;					// CR counter
volatile static uint8_t	ustatus;				// serial status

//=================================
// file-scope fn declarations
//=================================


//=================================
// source code
//=================================

//-----------------------------------------------------------------------------
// init_uart() initializes serial port vars
//	allows separate enabling of RX and TX usinf "rx" and "tx" booleans
//-----------------------------------------------------------------------------
//
void init_uart(uint32_t baudr, uint8_t enab){
	rxd_hptr = 0;										// rx buf head ptr
	rxd_tptr = 0;										// rx buf tail ptr
	rxd_stat = 0;										// rx buff status
	rxd_crcnt = 0;										// init cr counter
	// init uart periph.
	USART0.BAUD = (uint16_t)USART0_BAUD_RATE(baudr);	// baud rate
	USART0.CTRLA |= USART_RXCIE_bm;						// control = RX ISR enabled
	USART0.CTRLC = USART_SBMODE_bm | 0x03;				//	2stop bits, 8 data bits
	if(enab & ENABLE_RXD){
		PORTB.DIR &= ~RXDp;
		USART0.CTRLB |= USART_RXEN_bm;					//	RX=enabled
	}
	if(enab & ENABLE_TXD){
		PORTB.OUT |= TXDp;								// init I/O pins
		PORTB.DIR |= TXDp;
		USART0.CTRLB |= USART_TXEN_bm;					//	TX=enabled
	}
	ustatus = 0;
	return;
}

//-----------------------------------------------------------------------------
// putch, UART0
//-----------------------------------------------------------------------------
//
// SFR Paged version of putch, no CRLF translation
//
char putch(char c){

	// output character
	while (!(USART0.STATUS & USART_DREIF_bm));
	USART0.TXDATAL = c;
	return c;
}

//-----------------------------------------------------------------------------
// getch00 checks for input @ RX0.  If no chr, return '\0'.
//-----------------------------------------------------------------------------
//
// SFR Paged, waits for a chr and returns
// Processor spends most of its idle time waiting in this fn
//
char getch00(void){
	char c = '\0';		// default to null return

	if(rxd_tptr != rxd_hptr){			// make sure buffer not empty
		c = rxd_buff[rxd_tptr++];		// get chr from buff
		if(rxd_tptr == RXD_BUFF_END){	// and update tail pointer
			rxd_tptr = 0;
		}
	}
	return c;
}

//-----------------------------------------------------------------------------
// cleanline() cleans buffer up to and including 1st CR.  
//	Pull CHRS from buffer and discard until first CR is encountered.  Then, exit.
//-----------------------------------------------------------------------------
//
void cleanline(void){
	char c;	// temp char

	if(rxd_tptr != rxd_hptr){							// skip if buffer empty
		do{
			c = rxd_buff[rxd_tptr++];					// pull chr and update pointer
			if(rxd_tptr == RXD_BUFF_END){
				rxd_tptr = 0;
			}
		}while((c != '\r') && (rxd_tptr != rxd_hptr));	// repeat until CR or buffer empty
	}
	return;
}

//-----------------------------------------------------------------------------
// gotch00 checks for input @ RX0.  If no chr, return '\0'.
//-----------------------------------------------------------------------------
//
// returns 0 if no chr in buffer or if current chr is '\r'
//
char gotch00(void){
	char c = 0;

	if((rxd_tptr != rxd_hptr) && (rxd_buff[rxd_tptr] != '\r')){
		c = 1;								// set buffer has data
	}
	if(rxd_stat & RXD_BS){					// process backspace
		rxd_stat &= ~RXD_BS;				// clear flag
		putss("\b \b");						// echo clearing BS to terminal
	}
	return c;
}

//-----------------------------------------------------------------------------
// gotcr checks for '\r' @ RX0.  If no chr, return '\0'.
//-----------------------------------------------------------------------------
//
// returns 0 if no cr rcvd
//
char gotcr(void){
	char c;

	if(rxd_crcnt){
		c = 1;								// buffer has data
	}else{
		c = 0;								// buffer empty
	}
	return c;
}

//-----------------------------------------------------------------------------
// putss() does puts w/o newline
//-----------------------------------------------------------------------------
//
void putss (char* string){
	while(*string){
		if(*string == '\n') putch('\r');
		putch(*string++);
	}
	return;
}

//-----------------------------------------------------------------------------
// getss() copies input line to pointer dest, returns end of dest
//	updates head/tail pointers for dest
//-----------------------------------------------------------------------------
//
char* getss (char* dest, uint8_t maxlen){
	char	c;					// temp char
	char*	sp = dest;
	char*	spx = dest + maxlen;
	uint8_t	i = 0;				// cmd prefix flag

	*sp = '\0';								// pre-clear dest
	do{
		c = getch00();						// copy input to dest with length check
		if(c == HMKEY_CMD) i = 1;
		if((i) && (sp < spx)) *sp++ = c;
	}while(c);
	if(rxd_crcnt){							// update msg counter:
		cli();								// no interrupts for this calculation..
		rxd_crcnt--;						// decrement msg counter
		sei();
	}
	return sp;
}

//-----------------------------------------------------------------------------
// getstat() returns USART status byte. if param = TRUE, clear the flag after reading
//-----------------------------------------------------------------------------
uint8_t getstat(uint8_t clear_flag){
	uint8_t c;			// return reg

	cli();
	// capture status value
	c = ustatus;
	// process clear status cmd
	if(clear_flag){
		ustatus = BRK_NOP;
	}
	sei();
	return c;
}

//=================================
// ISR source code
//=================================

//-----------------------------------------------------------------------------
// USART0 rx intr.  Captures EOL-terminated RX data and places into circular buffer
//
ISR(USART0_RXC_vect){
	char	c;

	c = USART0.RXDATAL;
	if(c == '\0'){
		ustatus |= BRK_DET;								// set break detect
	}else{
		if((c > ESC) || (c == EOL)){					// only process EOL and printable ASCII+ (+ = including the space 0x80-0xff)
			if(c == EOL){
				c = '\0';								// null-term lines
			}
			rxd_buff[rxd_hptr++] = c;					// feed the buffer
			if(rxd_hptr >= RXD_BUFF_END){
				rxd_hptr = 0;							// wrap buffer ptr
			}
			if(rxd_hptr == rxd_tptr){
				rxd_stat |= RXD_ERR;					// buffer overrun, set error
			}
			if(c == '\0') rxd_crcnt++;					// increment msg count if EOL (now a null in the datastream) is detected
		}
	}
}

// eof