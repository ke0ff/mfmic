/********************************************************************
 ************ COPYRIGHT (c) 2022 by ke0ff, Taylor, TX   *************
 *
 *  File name: serial.c
 *
 *  Module:    Control
 *
 *  Summary:   This is the serial I/O module for the banksw/RDU app
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *    02-20-22 jmh:  creation date
 *
 *******************************************************************/
