/**
 * \file
 *
 * \brief NVMCTRL related functionality implementation.
 *
 (c) 2020 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms,you may use this software and
    any derivatives exclusively with Microchip products.It is your responsibility
    to comply with third party license terms applicable to your use of third party
    software (including open source software) that may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 */

/**
 * \defgroup doc_driver_nvmctrl_init NVMCTRL Init Driver
 * \ingroup doc_driver_nvmctrl
 *
 * \section doc_driver_nvmctrl_rev Revision History
 * - v0.0.0.1 Initial Commit
 *
 *@{
 */

#include "nvmctrl.h"
#include "ccp.h"
//#include "C:\Program Files (x86)\Atmel\Studio\7.0\Packs\Atmel\ATtiny_DFP\2.0.368\include\avr\iotn816.h"

/**
 * \brief Initialize nvmctrl interface
 * \return Return value 0 if success
 */
int8_t FLASH_0_init()
{

	// NVMCTRL.CTRLB = 0 << NVMCTRL_APCWP_bp /* Application code write protect: disabled */
	//		 | 0 << NVMCTRL_BOOTLOCK_bp; /* Boot Lock: disabled */

//	NVMCTRL.INTCTRL = 1 << NVMCTRL_EEREADY_bp; /* EEPROM Ready: enabled */
//	ccp_write_spm((void*)&NVMCTRL_INTCTRL, 1 << NVMCTRL_EEREADY_bp);
	
	return 0;
}

/**
 * \brief eeprom write
 */
int8_t eewr(uint8_t* addr, uint8_t bdata)
{
	while(!(NVMCTRL_INTFLAGS & NVMCTRL_EEREADY_bm));
	*addr = 0xff;
	ccp_write_spm((void*)&NVMCTRL_CTRLA, NVMCTRL_CMD_PAGEERASEWRITE_gc);
	*addr = bdata;
	ccp_write_spm((void*)&NVMCTRL_CTRLA, NVMCTRL_CMD_PAGEWRITE_gc);
	while(NVMCTRL_STATUS & NVMCTRL_EEBUSY_bm);
	return 0;
}

/**
 * \brief eeprom read
 */
uint8_t eerd(uint8_t* addr)
{
	return *addr;
}

/**
 * \eeaddr_nxt() finds next erased byte in EEPAGE.  addr is an offset and must be the start of a page
 */
uint8_t* eeaddr_nxt(uint8_t addr)
{
	uint8_t*	bp;
	uint8_t		i = EEPROM_PAGE_SIZE;
	
	ccp_write_spm((void*)&NVMCTRL_CTRLA, NVMCTRL_CMD_PAGEBUFCLR_gc);			// clear page buffer
	bp = (uint8_t*)(addr + EEPROM_START);								// start search addr
	while((*bp != 0xff) && (i)){										// look for 1st erased byte in page
		*bp++ = 0xff;													// prep for possible erase
		i--;
	}
	if(i == 0){															// if page full, erase page
		bp = (uint8_t*)(addr + EEPROM_START);
		ccp_write_spm((void*)&NVMCTRL_CTRLA, NVMCTRL_CMD_EEERASE_gc);
		while(NVMCTRL_STATUS & NVMCTRL_EEBUSY_bm);
	}else{
		ccp_write_spm((void*)&NVMCTRL_CTRLA, NVMCTRL_CMD_PAGEBUFCLR_gc);		// clear page buffer (for next guy)	
	}
	return bp;															// return the next empty spot
}

/**
 * \eeaddr_cur() finds last byte written in EEPAGE.  addr is an offset and must be the start of a page
 */
uint8_t* eeaddr_cur(uint8_t addr)
{
	uint8_t*	bp;
	uint8_t		i = EEPROM_PAGE_SIZE - 1;
	
	bp = (uint8_t*)(addr + EEPROM_START + EEPROM_PAGE_SIZE - 1);
	while((*bp == 0xff) && (i)){
		bp--;
		i--;
	}
	return bp;
}

/**
 * \brief eeprom write next empty space
 */
int8_t eewr_nxt(uint8_t bdata)
{
	uint8_t*	bp;
	
	bp = eeaddr_nxt(0);
	eewr(bp, bdata);
//	*bp = bdata;
//	NVMCTRL_CTRLA = NVMCTRL_CMD_WP_gc;
//	while(NVMCTRL_STATUS & NVMCTRL_EEBUSY_bm);
	return 0;
}

/**
 * \brief eeprom write next empty space
 */
uint8_t eerd_cur(void)
{
	uint8_t*	bp;
	
	bp = eeaddr_cur(0);
	return *bp;
}
