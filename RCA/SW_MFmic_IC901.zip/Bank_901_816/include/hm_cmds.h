/********************************************************************
 ************ COPYRIGHT (c) 2022 by ke0ff, Taylor, TX   *************
 *
 *  File name: hm_cmds.h
 *
 *  Module:    Control
 *
 *  Summary:   This is the header file for the hm133 MFmic fn.
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    09-17-22 jmh:  creation date
 *
 *******************************************************************/

//------------------------------------------------------------------------------
// extern defines
//------------------------------------------------------------------------------
#define	HM_BUFF_END		16			// HM-1xx MFmic buffer length
#define	MSG_BUFF_END	10			// HM-1xx MFmic buffer length

#define HM_HOLD_TIME	(1000/5) //MS1000
#define HM_SHFTIM		(10000/5)		// mic Fn/shft timer = 10 sec
#define PROC_INIT		0xff
#define	BRT_MAX			99
#define PGM_EEDIM		0xfa
#define PGM_EEBRT		0xfb
#define READ_EEDIM		0xf5
#define READ_EEBRT		0xf6

#define	NOP				FALSE			// no-operation flag.  Passed to functions that have the option to perform an action or return a status
#define	CLR				TRUE			// perform read-and-clear operation flag.  Passed to functions that have the option to perform read status and clear
#define	KEY_NULL		'~'				// null chr for HMD keycode LUT
#define KEYP_IDLE		0x00			// keypad ISR state machine state IDs
#define KEYP_DBDN		0x01
#define KEYP_PRESSED	0x02
#define KEYP_HOLD		0x03
#define KEYP_DBUP		0x04
#define	KEY_PR_FL		0x01			// key-pressed bit field
#define	HMKEY_CMD		'~'				// HM key command prefix
#define	KEY_HOLD_FL		0x02			// key-hold bit field
#define	KEY_PRESCALE	10				// sets COL hold time (in ms +1)
#define HM_KEY_HOLD_TIME (PSEC1)		// keypad hold timer value (~~ 1 sec)
#define SHFT_HOLD_TIME	(PSEC10) 		// MFmic func-shift timeout (~~ 10 sec)
#define DFE_TO_TIME		(PSEC10)		// dfe timeout value
// keypad hold timer value (~~ 1 sec)
#define KEY_HOLD_TIME	((HM_KEY_HOLD_TIME * PS_PER_TIC)/KEY_PRESCALE)
#define	KEY_HOLD_KEY	0x8000			// set hi bit of key buffer entry to signal hold
#define	KEY_RELEASE_KEY	0x4000			// key release keycode
//#define	KHOLD_FLAG		0x40			// flag bit for key hold character
//#define	KREL_FLAG		0x40			// flag bit for key release character

/*  HM-151 Keypad map:
=============================================
|	LOKEY	|	CALLKEY	|	XFCKEY			|
|	UPKEY	|	VMKEY	|	MWKEY			|	HM-133:
|	DNKEY	|	F1KEY	|	F2KEY	________|	F1KEY = "DTMF"; F2KEY = "FUNC"
|	1		|	2		|	3		|	A	|
|	4		|	5		|	6		|	B	|
|	7		|	8		|	9		|	C	|
|	*		|	0		|	#		|	D	|
=============================================
*/

// HM MFmic character defines
#define	LOKEY		'L'
#define	CALLKEY		'T'
#define	XFCKEY		'X'
#define	UPKEY		'/'
#define	VMKEY		'V'
#define	MWKEY		'M'
#define	DNKEY		'\\'
#define	F1KEY		'F'					// This is the HM-151 keycode that is in the same location as the HM-133 "FUNC" button {HM-133 doesn't send a code for this button}
#define	F2KEY		'G'					// HM-151 "F-2" {HM-133 DTMF button which doesn't send a code}
// shifted keys
#define	SH_LOKEY	'p'
#define	SH_CALLKEY	'o'
#define	SH_XFCKEY	'n'
#define	SH_UPKEY	'k'
#define	SH_VMKEY	'm'
#define	SH_MWKEY	'l'
#define	SH_DNKEY	'j'
#define	SH_F1KEY	'|'
#define	SH_F2KEY	'!'
#define	SH_1		'a'
#define	SH_2		'b'
#define	SH_3		'c'
#define	SH_A		'q'
#define	SH_4		'd'
#define	SH_5		'e'
#define	SH_6		'f'
#define	SH_B		'r'
#define	SH_7		'g'
#define	SH_8		'h'
#define	SH_9		'i'
#define	SH_C		's'
#define	SH_STR		'+'
#define	SH_0		'`'
#define	SH_PND		'$'
#define	SH_D		't'

//------------------------------------------------------------------------------
// Fn defines
//------------------------------------------------------------------------------
char process_CMD(uint8_t flag);
uint8_t brt_level(uint8_t cmd);
uint8_t got_hm_asc(void);
uint8_t hm_asc(void);
void hm_cmd_get(char* sptr, uint8_t pcmd);
char* msg_ptr(void);
void sto_psub(uint8_t mode);
uint8_t rd_psub(void);

// end hm_cmds.h