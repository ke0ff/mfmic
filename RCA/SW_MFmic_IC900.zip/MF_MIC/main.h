/********************************************************************
 ************ COPYRIGHT (c) 2022 by ke0ff, Taylor, TX   *************
 *
 *  File name: main.h
 *
 *  Module:    Control
 *
 *  Summary:   This is the header file for the banksw/rdu app.
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    02-20-22 jmh:  creation date
 *
 *******************************************************************/

//------------------------------------------------------------------------------
// extern defines
//------------------------------------------------------------------------------

#define TIMER_CLEAR	0xffff				// timer clear cmd
#define SYSCLK		3333333				// Hz

// single-slope PWM/TimerA defines
#define PWM_PERCENT_DFLT	25
#define PWM_FREQ			5000
#define PWM_PER				(SYSCLK / PWM_FREQ)
#define PWM_PCNT_INIT		((PWM_PERCENT_DFLT * PWM_PER) / 100)
#define DIM_PWM				30
#define RAMP_PWM_0			0					// brightness ramp-up profile
#define RAMP_PWM_1			(DIM_PWM/6)
#define RAMP_PWM_2			(DIM_PWM/2)
#define RAMP_PWM_3			(5*DIM_PWM/6)
#define RAMP_PWM_4			(DIM_PWM)
#define BRT_PWM				70

// PA0 = UPDI
#define DMA3		0x02				// PA1	(MUX address b3 out, also feeds to the LUT sub-system)
#define P23			0x04				// PA2	(discrete button MUX pulse output)
#define PULSE2		0x08				// PA3	(MUD2 input ...??? do we need this ???)
#define DMA2		0x10				// PA4	(MUX address b2 out)
#define DMA1		0x20				// PA5	(MUX address b1 out)
#define DMA0		0x40				// PA6	(MUX address b0 out)
#define PULSE1		0x80				// PA7	(MUX-mirror pulse output)

#define A11o		0x01				// PB0	(bank out lsb)
#define A12o		0x02				// PB1	(bank out msb)
#define TXDp		0x04				// PB2 = TXD (HST>>TRG)
#define SELB		0x04				// PB2  (select input msb)
#define DIMMER		0x04				// PB2  (dimmer input)
#define RXDp		0x08				// PB3 = RXD (HST<<TRG)
#define GAn			0x10				// PB4	(LUT0 output)
#define PWMOUT		0x20				// PB5	(drives LED switch for brightness control)

#define CHECK		0x01				// PC0	(CHECK button output)
#define SELB1		0x01				// PC0	(MARK-I SELB)
#define SEL_STP		0x02				// PC1	(increment bank pulse input)
#define SELA		0x02				// PC1	(select input lsb)
#define RESETg		0x04				// PC2	(IC-901 reset output, drive as open collector/gnd)
#define TXLED		0x08				// PC3	(LUT1 input, LUT1 feeds input to LUT0)

#define ADR0		0
#define ADR1		4
#define ADR2		2
#define ADR3		6
#define ADR4		1
#define ADR5		5
#define ADR6		3
#define ADR7		7

// DMA is ordinal address, 0x00 - 0x0f.  Hi-bit indicates PULSE2, else address targets PULSE1
// PULSE2 cmds
#define CMD_DIAL_UP	'Y'
#define DMA_DIAL_UP	(0x80 | ADR0)
#define CMD_DIAL_DN	'y'
#define DMA_DIAL_DN	(0x80 | ADR3)
#define CMD_MIC_UP	'I'
#define DMA_MIC_UP	(0x80 | ADR2)
#define CMD_MIC_DN	'i'
#define DMA_MIC_DN	(0x80 | ADR1)
#define CMD_SMUTE	'u'
#define DMA_SMUTE	(0x80 | ADR4)
#define CMD_CHECK	'k'
#define DMA_CHECK	(0x80 | ADR7)
#define CMD_LOCK	'Z'
#define DMA_LOCK	(0x80 | ADR6)
// PULSE1 cmds
#define CMD_VM		'f'
#define DMA_VM		13
#define CMD_CALL	'C'
#define DMA_CALL	15
#define CMD_BAND	'B'
#define DMA_BAND	14
#define CMD_MODE	'o'
#define DMA_MODE	12
#define CMD_MHZ		'M'
#define DMA_MHZ		11
#define CMD_HL		'H'
#define DMA_HL		8
#define CMD_SQUP	'Q'
#define DMA_SQUP	9
#define CMD_SQDN	'q'
#define DMA_SQDN	10

#define CMD_SUB		'S'
#define DMA_SUB		5
#define CMD_MS		'X'
#define DMA_MS		7
#define CMD_MW		'w'
#define	DMA_MW		6
#define CMD_SET		't'
#define DMA_SET		4
#define CMD_TS		'T'
#define DMA_TS		3
#define CMD_TSQ		'm'
#define DMA_TSQ		0
#define CMD_VOLUP	'V'
#define DMA_VOLUP	1
#define CMD_VOLDN	'v'
#define DMA_VOLDN	2
#define CMD_RESET	'R'
#define DMA_RESET	0xff
#define CMD_BRIGHT	'L'
#define DMA_BRIGHT	0xff
#define CMD_BANK	'a'
#define DMA_BANK	0xff


// end main.h