/********************************************************************
 ************ COPYRIGHT (c) 2022 by ke0ff, Taylor, TX   *************
 *
 *  File name: serial.h
 *
 *  Module:    Control
 *
 *  Summary:   This is the header file for serial I/O.
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    02-20-22 jmh:  creation date
 *
 *******************************************************************/

//------------------------------------------------------------------------------
// extern defines
//------------------------------------------------------------------------------
#define TIMER_MIS_AMASK	(TIMER_MIS_TAMMIS | TIMER_MIS_CAEMIS | TIMER_MIS_CAMMIS | TIMER_MIS_TATOMIS)


#define RXD_ERR			0x01			// rx data error
#define RXD_CHAR		0x08			// rx char ready
#define RXD_TSIPRDY		0x10			// tsip msg ready
#define	RXD_TSIPERR		0x20			// tsip msg error
#define TXD_CHRS		0x01			// tx chr sent
#define TXD_ERR			0x10			// tx data error (buffer overflow)
#define TXD_CERR		0x20			// tx data error (collision)
#define TXD_JAMMER		0x40			// jammer code detect
#define TXD_SND			0x80			// tx data sending
#define SOH		0x01
#define ETX		0x03
#define	EOT		0x04
#define AKN		0x06
#define	EOM1	13						// <CR> is EOM1
#define DLE		0x10
#define XON		0x11
#define XOFF	0x13
#define NAK		0x15
#define CAN		0x18
#define ESC		27
#define SW_ESC	0xa5					// sw restart escape code
#define	myEOF	26

// xmodem defines

// Timer and retry limits
#define	XM_TO			(3*ONESEC)		// 3 seconds for xmodem timeout
#define ACKTRIES		10				// # tries to do start of packet before abort
										// this gives 30 sec to start an xmodem transfer in CRC before
										// SW reverts to checksum
#define	CIV_PREA		0xfe			// CIV message preamble
#define	CIV_HADDR		0xe0			// cntlr addr
#define	CIV_RADDR		0x70			// radio address
#define	CIV_EOM			0xfd			// CIV message end-of-msg
#define	CIV_OK			0xfb			// CIV message OK
#define	CIV_NG			0xfa			// CIV message no-good
#define	CIV_JAM			0xfc			// CIV jammer code
#define CIV_TIMEOUT 	100				// (ms) CIV send chr timeout limit
#define	CIV_RETRY_LIM	4				// retry limit
#define	CIV_JAMOUT		30				// (ms) CIV jammer code timeout
#define	CIV_MSGWAIT		50				// (ms) CIV message wait delay

//------------------------------------------------------------------------------
// public Function Prototypes
//------------------------------------------------------------------------------

void init_uart(uint32_t baud);
char gotcr(void);
/*
void initserial();
char putchar0(char c);
char putdch(char c);
U8 puthex(U8 dhex);
char getchr(void);
char gotchr(void);
int putss(const char *string);
char getch00(void);
U32 init_uart0(U32 baud);
char set_baud(U32 baud);

void rxd_intr(void);
*/
