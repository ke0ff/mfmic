/********************************************************************
 ************ COPYRIGHT (c) 2022 by ke0ff, Taylor, TX   *************
 *
 *  File name: main.c
 *
 *  Module:    Control
 *
 *  Summary:   This is the DFC bankswitch and IC-901 MFmic protocol app for the ATTiny
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *
 *				HW NOTE: Need to configure MUP/DN data line to break sneak-power path:
 *					{{ e.g.: put nand-NPN at HM133, and pullup to +V at ATTINY
 *					{{ a diode in series with the data line with K pointed at the HM-133 adapter seems to work.
 *						!!! Need to move R42 on IC-901 controller to the ATTINY side of the series diode !!!
 *				] need to modify C8051F531 MFmic code to use non '~' prefix for debug messages
===============================================
 * 10/16/22 jmh:	7658 bytes PGM, 162 bytes RAM
 *				- Added interrogate of PTTsub selection
 *				- Finished coding the ADC flip-flop for the mic u/d and light sensor capture
 *				- Finished modifying process_DIMMER() to use the LSADC value to do auto-bright switch based on light sensor reading
 *				- Validated button-presses and EEPROM behavior.  All functions correct, ready for release.
 *
 * 10/15/22 jmh:
 *				- Added LOCK button as one of the SH_XFC button options
 *				- congregated all of the error beeps into a function, do_beep_err() to save some FLASH.
 *				- got pttsub mode 2 to work... requires A LOT of post-button activity delay (about 200ms).  Maybe not worth doing here.
 *				- cleanup of bank management functions including per-bank storage of pttsub mode
 *				- fixed EEPROM routines (including bank walking byte)
 *				- fixed LOCK function
 *				- fixed FUNC beep for HM-151/207.  F-1 on these mics issues an error beep. -- possibly use F-1 on the HM-151 (CLR on HM-207)
 *					for mic LED bright control.
 *
 * 10/14/22 jmh:
 *				- RevB HW mod support (RevA is now deprecated):
 *					[] Moved A11o to PC0, and A12o to PB2
 *					[] Added ADC to monitor Mic U/D (serial data) signal (allows hot-swap of HM-14-style up/dn buttons) - code ported
 *						from IC-900 MFMic application.
 *					[] LSDAC (PB0) provision for light sensor ADC input on PB0
 *					[] Imported IC-900 MFmic code to accomplish HM-14 hotswap
 *				- Added SEC/CLI swap for chk_timer() Fns (copied from IC-900 MFmic)
 *				- fixed DMA_TSQ issue (was posing as DMA_NOKEY, so it was ignored in "main.c - exec()"
 *				- !! Issues with FUNC-3 and FUNC-# !! These key sequences are HM-133 specials that modify the HM-133 behavior.
 *					Abandoned RPN format so that the first key after FUNC is never a digit (or #).  Now MFmic parametrized commands
 *					are prefix-based.  First the command key is entered, then the value to be assigned.  Invalid values give error
 *					beeps
 *				- BRT/DIM now use fixed brightness table to establish 10 discrete levels of bright.  Allows brightness profile to be
 *					adjusted at compile-time
 *				- beep cleanup.  Added 825 Hz "error" beep (Fmin is 814 Hz)
 *				- mechanized PTTsub mode to support modes "1" (smute) and "0" (off)
 *				- Swapped SUB and TS so that SUB is accessible without having to press "FUNC"
 *
 * 10/02/22 jmh:
 *				- code cleanup.  Sequestered MARK defines and broke out process_BANK() for each MARK.
 *				- Cleaned up function beeps and shift actions.
 *				- Added fact-int as shift-XFC with "9" in the RPN register as a safety interlock.
 *
 * 09/30/22 jmh:
 *				- TCD now produces 1600Hz tone @PC1.  Need to add hardware to key buzzer and also code to turn on/off beeper.
 *				- Added do_beep() function and support Fns.  Had to disable process_BANK() but still run process_BANK(IPL_CMD).
 *					The IPL is needed to init the IPL bank and reset the IC-901 MCU.  However, since SEL_STP was hijacked for the beeper
 *					the normal periodic execution of process_BANK() was non-sequitr.
 *				- Added do_beep() calls to all commented spots that were copied from the IC-900 RDU code.  There is an initial do_beep(1)
 *					at the end of the main() IPL sequence.  This "initializes" the beeper output to follow the settings in system_init()
 *				- Beeper verified with LA {need to add NPN switch to PC1 and connect collector to J2-3
 *
 * 09/29/22 jmh:
 *				- Main mute is now invoked with smute-hold
 *
 * 09/28/22 jmh:
 *				- Improved robustness of serial input by placing limits on getss() - there is now a maxlen param that limits how much
 *					data getss can xfr.  Once limit is reached, getss still clears out the serial buffer (the remaining data is lost).
 *				- getss() now looks for the HMKEY_CMD prefix before moving data.  Prevents obviously bogus messages from reaching the next layer
 *				- fixed pttsub feature, was ORing with DMA_KREL but DMA_KREL is a code character, so the release action wasn't getting trapped.
 *				- added debounce to pttsub to prevent short TX cycles from tripping the action
 *				- coded a head-tail architecture for lcl_cmd[].  added get_lcl(), got_lcl(), put_lcl(), and full_lcl() support Fns.
 *				- cleaned up EEPROM routines
 *				- produced EEPROM address defines for bright, dim, and 4 PTTsub mode bytes (sto_psub() and rd_psub() wr/rd the mode value
 *					using A11/A12 as the index).
 *				-- added calls to sto_psub()/rd_psub() to update the mode register when bank switching is taking place.
 *					<<still need to DO something with the mode reg...>> 
 * 
 * 09/27/22	jmh:
 *				Accomplished port of IC900 RDU Clone code for MFmic.  Basic features working.  Need work on the following:
 *				* add code to set PTTsub mode (0 - 3) plus store to EEPROM.
 *				* add code to implement all 3 PTTsub modes
 *				- Fn/shft+ up/dn does dial up/dn.  Implemented toggle mechanism to autostep if either up/dn button is held
 *				- Fn/shft timer timeout now set to 10 sec
 *
 * 02/15/22 jmh:  by Joe Haas, KE0FF (creation date)
 *
 *******************************************************************/
/*
 * Created: 2/15/2022 21:22
 * Author : joe.haas
 * Executes the ATtiny816 SRAM bank-switch & RCI application for the IC-901 Control Unit.
 *
 * Bank_901-816: Bank-switch controller for the IC-901 control unit SRAM.  Allows an 8Kx8 SRAM to be installed in place
 *	of the original 2Kx8 device to allow 4 banks of configuration to be supported.  Primarily, this allows 4 different
 *	memory configurations that can be user selected.  In addition, the device will eventually support the RDU remote
 *	control application using a wired or BT connection to send control commands to the ATTINY which are then decoded
 *	and the outputs to the button MUX-mirror logic driven as required.
 *
 * There are several build-options:
 * Mark-I: This is the first, bluetooth, remote button modification.  The BT system runs as-is, and the ATtiny-816 runs
 *	minimal interfaces: 2-wire bank inputs, PWM output, and DIMMER input on TXD (PB2).
 *
 * Mark-II: 2-wire bank selects, wired remote (using MU/D2 wire), PWM dimmer controlled via UART (no DIMMER interface)
 *
 * Mark-III: 1-wire or 0-wire bank select, wired remote (using MU/D2 wire), PWM dimmer using DIMMER output (PB2).
 *
 * The wired versions shall make use of MU/D2 which means that the A-unit "host" will have to echo commands to mimic
 *	the U/D function. This requires that there be a mechanization to code the microphone up/dn buttons into serial cmds.
 *
 * To implement the bank switching properly, a factory restart for each bank selection must be performed once the
 *	hardware mods are complete.  Starting at bank 0 with the radio power OFF, press "CHECK" and "MW" and then turn
 *	on the radio. Turn off the radio power, advance the bank#, and repeat the restart process until all 4 banks are
 *	initialized.
 *
 * The application supports 2 inputs: A11i and A12i; and 3 outputs: A11o, A12o, and RESETG.
 * On power-up, the application sets RESETG = 1, waits 10ms, and reads A11 and A12 and passes those values
 *	to A11C and A12C, respectively.  After another 5ms, RESETG is cleared to 0 and the application enters the main loop.
 *	In the main loop, the algorithm looks for any change to A11 or A12 (debounced 15ms).  If, after debounce, a
 *	change is detected, the algorithm sets RESETG, waits 10ms, passes A11/12 to A11C/12C, waits another 5 ms,
 *	then clears RESETG.  Control then passes back to the top of the loop.
 *
 * The only interrupt envisioned (not yet implemented) is a timer interrupt to establish the ms time intervals for
 *	debounce and reset periods.
 *
 *	The TUNE macro enables the tune loop compile to allow the wait() loop to be measured and adjusted.  This macro
 *		is commented out for the production build.
 *
 * PWM on the SPARE pin (PB5) is set to 10KHz, 50% to drive blanking input on the 4511 LED driver for brightness control.
 *
 * Future efforts will utilize other aspects of the 816 to implement the HM-133 RDU remote-control protocol for the IC901
 *	control head.
 *
 *		+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 * Bank-switch hardware requirements:
 *		Parts List:
 *		(1)		8Kx8 SRAM in an SOIC package (such as 6C6256, in an SOIC package, from Alliance Memory)
 *		(1)		voltage monitor IC with a 4V detection threshold and a GND-true, open collector/drain output
 *				(such as Diodes Inc, APX803S-40SR-7)
 *		(1)		small rectangle of Kapton tape (A.R.)
 *		(AR)	30AWG wire-wrap wire, solid, any color.
 *		(1)		Bank select/reset sub-assembly comprised of the target MCU for this code, a selection switch,
 *					and any other components and wires needed.
 *
 *	1) Dissassemble the IC-901 control head. Remove the LCD to expose the backside of the PCB.
 *	2) Remove IC2 and IC5.
 *	3) Bend pin 23 of the new 8Kx8 SRAM part up approximately 45 degrees.
 *		Bend pins 1, 2, 27, and 28 up approximately 15 degrees.
 *	4) Place a small rectangle of Kapton tape near pins 1 and 24 of IC2 to insulate pins 1, 2, 27, & 28 of the new SRAM.
 *	5) Install the new SRAM at IC5 by aligning pin 14 of the SRAM with pad-12 of the IC2 footprint.
 *	6) Install short jumper wires as follows:
 *		SRAM-28 to SRAM-26
 *		SRAM-27 to IC2-21
 *	7) Install new voltage monitor IC at IC5.
 *	8) (OPTIONAL) install 100pF caps to GND at SRAM-23, SRAM-2, SRAM-28, and IC5-1.
 *	9) Connect the bank-select subassembly signals & power/GND as follows:
 *		Bank select A11 to SRAM-23
 *		Bank select A12 to SRAM-2
 *		bank-select power to SRAM-28
 *		Bank-select GND to IC2-12
 *		Bank-select RESET to IC5-1
 *	10) Secure the bank-select sub-assembly and re-assemble the LCD and control head
 *
 */

// !! CONDITIONAL COMPILE FLAGS MOVED TO main.h !!

#include <atmel_start.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <driver_init.h>
//#include <tcd.h>
#include "main.h"
#include "serial.h"
#include "nvmctrl.h"
#include "hm_cmds.h"
#include "adc_basic.h"
#include <avr/pgmspace.h>


#define BSTATE0		0						// bank select state machine state enums
#define BSTATE1		1
#define BSTATE2		2
#define BSTATE3		3

#define RBSTATE0	0						// rbank select state machine state enums
#define RBSTATE1	1
#define RBSTATE2	2
#define RBSTATE3	3
#define RMT_IDLE_CMD	0xff				// idle cmd signal to remote bank state machine
#define RMT_BANK_CMD	0x80				// cmd signal bit-flag to remote bank state machine

#define USTATEI		10						// UART state enums
#define USTATE0		0
#define USTATE1		1
#define USTATE2		2
#define USTATE3		3

#define SBAUD		115500 //19200L			// HM133 remote control baud rate

#define SSTATE0		0						// SMUTE state enums
#define SSTATE1		1
#define SSTATE2		2
#define SSTATE3		3
#define SSTATE00	4
#define SSTATE22	5

#define GET_UART	1
#define GET_LOCAL	0

/////////////////////////////////////
// file local fn declare
void set_bank(uint8_t in);
void reset_cyc(uint8_t bout);
uint8_t process_BANK(uint8_t cmd);
uint8_t process_rBANK(uint8_t cmd);
uint8_t process_UART(uint8_t cmd);
uint8_t process_DIAL(uint8_t cmd);
uint8_t process_DIMMER(uint8_t cmd);
uint8_t exec_cmd(uint8_t vect);
void pttsub_dly(void);
void set_button(uint8_t bpd);
void set_DMA(uint8_t addr);
void set_pulse1(void);
void clear_pulse(void);
void set_pulse2(void);
void init_ports(void);
void init_lut(void);
void init_pwm(void);
uint8_t pulse_clear(void);
void put_lcl(char c);
uint8_t got_lcl(void);
char get_lcl(void);
uint8_t full_lcl(void);
void process_FACTI(void);

/////////////////////////////////////
// file local variables
volatile static	uint8_t	rb_active;					// remote active flag
volatile static	uint8_t	pfx_reg;					// prefix cmd memory
volatile static	uint8_t	remote_bank;				// remote bank cmd signal register
volatile static	uint8_t	pttsub_reg;					// pttsub mode register
#define MAX_LCL	20
volatile static	char	lcl_cmd[MAX_LCL];			// internal command signal (string) to UART command state machine
											// if lcl_cmd[0] != '\0', execute from string
volatile static	uint8_t	lcl_head;					// head/tail ptrs for lcl_cmd
volatile static	uint8_t	lcl_tail;

volatile static	uint8_t	dial_togg;					// dial_toggle enable
volatile static	uint8_t	pcm;						// txled state memory

volatile static	uint8_t	dim_state;					// LED brightness state

#define NUM_RAMPS	5
volatile static	uint8_t	ramp[NUM_RAMPS] = { RAMP_PWM_0, RAMP_PWM_1, RAMP_PWM_2, RAMP_PWM_3, RAMP_PWM_4 };
// signature, version, and (c) stamp:
volatile const char version[] PROGMEM = { "IC901MFMV1.0,(c)KE0FF101622" };

/////////////////////////////////////
// fn macros
//
// bank select port assignment macros
#if MARK == 1
#define get_bank(var) var = PORTC.IN & (SELB1|SELA)
#endif
#if MARK == 2
#define get_bank(var) var = ((PORTB.IN & SELB) | (PORTC.IN & SELA)) >> 1
#endif


////////////////////////////////////////////////////////////////////////////                                             
//			        ==     ==     =     =======  =     =        
//			        = =   = =    = =       =     ==    =        
//			        =  = =  =   =   =      =     = =   =        
//			        =   =   =  =     =     =     =  =  =        
//			        =       =  =======     =     =   = =        
//			        =       =  =     =     =     =    ==        
//			        =       =  =     =  =======  =     =        
////////////////////////////////////////////////////////////////////////////
// main()
int main(void){
	volatile static char c;

	atmel_start_init();										// init MCU
	timer_ipl();
	init_ports();
	init_lut();
	init_pwm();
	set_beep_freq(0);
	lcl_head = 0;											// init head/tail ptrs for lcl_cmd
	lcl_tail = 0;
	c = version[0];											// this ensures that the (c) signature gets included in the FLASH image
	c++;
	sei();													//enabling global interrupt

//********************************************************* debug
#ifdef	TUNE	// debug loop
	
	PORTC.DIR = PORTC.DIR | A11o | RESETg;					// assert RESET and wait (failsafe... RESETg should have already been asserted during init)
	PORTA.DIR = PORTA.DIR | DMA0;							// set DMA = out
	PORTB.OUT = PORTB.OUT | A12o;
	while(1){
		PORTB.OUT = PORTB.OUT ^ 0x20;

		PORTC.OUT = PORTC.OUT | RESETg;						// assert RESET and wait
		PORTA.OUT = PORTA.OUT | DMA0;						// toggle reset and wait with fastest delay - used to tune the delay loop constants
		wait_T(RSTWAIT);									// Adjust GPIO wait to get a 10ms square-wave period at RESETg
		PORTC.OUT = PORTC.OUT & ~RESETg;					// assert RESET and wait
		PORTA.OUT = PORTA.OUT & ~DMA0;
		wait_T(RSTWAIT);
	}
//********************************************************* debug

#else	// This is the start of production main()

	// process initialization calls
	rb_active = 0;											// remote bank active flag
//	wdr();													// kick wd
	process_BANK(IPL_CMD);
	process_rBANK(IPL_CMD);
	process_UART(IPL_CMD);
	process_DIAL(IPL_CMD);
#if	MARK == 3
	process_DIMMER(IPL_CMD);
	process_CMD(IPL_CMD);
	do_beep(1);
	//
	/* MFmic UI application */
    while (1) // main loop (forever)
    {
		// run each process function...
		if(process_rBANK(NORM_CMD)){						// process remote bank select
			rb_active = 1;									// lockout changes...
		}
		process_DIAL(NORM_CMD);								// process mute-on-tx feature
		process_DIMMER(NORM_CMD);							// process dimmer input
		process_CMD(NORM_CMD);								// process HM messages
		process_UART(NORM_CMD);								// process UART commands
#endif
    } // end main while() loop
#endif
} // end main()
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////
// read_bank() returns the bank setting
//
uint8_t read_bank(void){
	uint8_t	i = 0;
	
	i = (PORTB_OUT & A12o) >> 1;								// mask out bits and apply updated outputs
	i |= PORTC_OUT & A11o;								// mask out bits and apply updated outputs
	return i;
}
/////////////////////////////////////
// set_bank() updates the bank outputs per the passed param
//	SELA (PC1) maps to A12 (PB2)
//	SELB (PC0) maps to A11 (PC0)
//
void set_bank(uint8_t in){
	uint8_t	i = 0;
	uint8_t	j = 0;
	
	if(in & 0x2) i = A12o;												// mask addr outputs
	if(in & 0x1) j = A11o;												// mask addr outputs
	PORTB_OUT = (PORTB_OUT & ~(A12o)) | i;								// mask out bits and apply updated outputs
	PORTC_OUT = (PORTC_OUT & ~(A11o)) | j;								// mask out bits and apply updated outputs
	return;
}

/////////////////////////////////////
// set_bank() updates the bank outputs per the passed param
//
void reset_cyc(uint8_t bout){

	PORTC.OUT = PORTC.OUT & ~RESETg;									// assert RESET and wait
	PORTC.DIR = PORTC.DIR | RESETg;
	set_bank(bout);														// assert bank outputs
	wait_T(RSTWAIT);													// delay reset wait
	PORTC_DIR &= ~RESETg;												// release RESET (by making it an input)
	return;
}

/////////////////////////////////////
// process_BANK() handles the bank update state-machine
//
uint8_t process_BANK(uint8_t cmd){
//----------------------------------
#if MARK == 1				// MARK 1 sel-step input
	static	uint8_t	pold;		// PORTC input memory reg, init to force update during first loop
	static	uint8_t	pnew;		// PORTC new state input memory reg
	uint8_t	p;					// port input temp
	static	uint8_t	state;		// state machine register

	get_bank(p);															// grab bank inputs and mask them
	if(cmd == IPL_CMD){
		reset_cyc(p);														// assert IPL reset cycle
		pold = p;															// init pold & state machine
		state = BSTATE0;
		chk_tmr1(TIMER_CLEAR);
	}else{
		/* address change-capture application */
		switch(state){
			default:
			case BSTATE0:													// idle state... looking for change to select inputs
			if(p != pold){
				chk_tmr1(DEBOUNCE);											// change detected, set debounce,
				pnew = p;													// save new perceived select input,
				state = BSTATE1;											// and advance state machine
			}
			break;

			case BSTATE1:													// Debounce state... looking to see if select inputs deviate (bounce)
			if(!chk_tmr1(0)){												// if debounce timer expires, the inputs are accepted
				chk_tmr1(CHNGWAIT);											// set the change-wait timer
				state = BSTATE2;											// advance the state machine
				}else{
				if(p != pnew) state = BSTATE0;								// invalid input (circuit bounce), abort and return to idle
			}
			break;

			case BSTATE2:													// Change-Wait state... delay select processing to allow for the operator to advance mechanical switch again
			if(!chk_tmr1(0)){												// after change-wait time has expired, process the input:
				PORTC.OUT = PORTC.OUT & ~RESETg;							// assert RESET
				PORTC.DIR = PORTC.DIR | RESETg;
				set_bank(pnew);												// assert new bank outputs
				chk_tmr1(RSTWAIT);											// set RSTWAIT delay
				state = BSTATE3;											// advance state machine (processes RSTWAIT delay)
				}else{
				if(p != pnew){
					state = BSTATE0;										// invalid input (circuit bounce), abort and return to idle
				}
			}
			break;

			case BSTATE3:													// Process reset wait delay
			if(!chk_tmr1(0)){												// when reset delay expires...
				PORTC_DIR &= ~RESETg;										// release RESET,
				pold = pnew;												// update pold
				state = BSTATE0;											// process complete, return to idle
			}
			break;
		} // end switch()
	} // end if-cmd
	return 0;
#endif // MARK 1

//----------------------------------
#if MARK == 2		// MARK 3 sel-step input
	// Uses EEPROM page 0 to store new bank for recall on power cycle.  Uses "walking byte" method to wear-level
	//	the EEPROM by looking for the first 0xFF byte when storing a new value
	static	uint8_t	banko;		// PORTC input memory reg, init to force update during first loop
	static	uint8_t	state;		// state machine register
			uint8_t p;
			uint8_t i;			// temp

	p = PORTC.IN & SEL_STP;												// capture step input
	if(cmd == IPL_CMD){
		i = eerd_cur() & 0x03;											// get saved EE bank
		banko = i;														// init banko & state machine
		sei();															// enabling global interrupt... NOW!
		reset_cyc(banko);												// assert IPL reset cycle
		state = BSTATE0;
		chk_tmr1(TIMER_CLEAR);
		pttsub_reg = rd_psub();											// fetch saved pttsub mode
	}else{
		/* address change-capture application */
		switch(state){
			default:
			case BSTATE0:												// idle state... looking for change to step input
				if(!p){
					chk_tmr1(DEBOUNCE);									// change detected, set debounce,
					state = BSTATE1;									// and advance state machine
				}
				break;

			case BSTATE1:												// Debounce state... looking to see if select inputs deviate (bounce)
				if(!chk_tmr1(0)){										// if debounce timer expires, the inputs are accepted
					PORTC.OUT = PORTC.OUT & ~RESETg;					// assert RESET
					PORTC.DIR = PORTC.DIR | RESETg;
					banko += 1;											// advance bank and mask relevant bits
					banko &= 0x03;
					eewr_nxt(banko);									// store new bank to EEPROM
					reset_cyc(banko);									// assert new bank outputs
					state = BSTATE2;									// advance the state machine
					pttsub_reg = rd_psub();								// fetch saved pttsub mode
				}else{
					if(p) state = BSTATE0;								// invalid input (circuit bounce), abort and return to idle
				}
				break;

			case BSTATE2:												// Change-Wait state... delay select processing to allow for the operator to advance mechanical switch again
				if(!chk_tmr1(0)){										// after change-wait time has expired, process the input:
					PORTC_DIR &= ~RESETg;								// release RESET,
					state = BSTATE0;									// advance state machine (processes RSTWAIT delay)
				}
				break;
		} // end switch()
	} // end if-cmd
	return 0;
#endif // MARK 2

//----------------------------------
#if MARK == 3				// MARK 3
	// Uses EEPROM page 0 to store new bank for recall on power cycle.  Uses "walking byte" method to wear-level
	//	the EEPROM by looking for the first 0xFF byte when storing a new value
	uint8_t i;			// temp

	if(cmd == IPL_CMD){
		i = eerd_cur() & 0x03;											// get saved EE bank
		reset_cyc(i);													// assert IPL reset cycle
		chk_tmr1(TIMER_CLEAR);
		pttsub_reg = rd_psub() & 0x03;									// fetch saved pttsub mode
	} // end if-cmd
	return 0;

#endif	// MARK 3
//----------------------------------
} // end process_BANK

/////////////////////////////////////
// process_rBANK() handles the remote bank update state-machine
//	returns true if a remote command is processed
//
uint8_t process_rBANK(uint8_t cmd){

#if (MARK == 2) || (MARK == 3)

	uint8_t	pnew;				// new addr temp
	uint8_t	rtrn = 0;			// return value
static	uint8_t	state;			// state machine register

	if(cmd == IPL_CMD){
		remote_bank = RMT_IDLE_CMD;										// use remote cmd to input remote bank select (initialize to invalid)
		state = RBSTATE0;
		chk_tmr2(TIMER_CLEAR);
	}else{
		if(remote_bank != RMT_IDLE_CMD){								// if remote command..
			/* remote address change-capture application */
			switch(state){
				default:
					pnew = 0;											// failsafe
					remote_bank = RMT_IDLE_CMD;
					state = RBSTATE0;									// process complete, return to idle
					break;

				case RBSTATE0:											// Process falling edge of DMA
					pnew = remote_bank & (0x03);						// mask bank address
					PORTC.OUT = PORTC.OUT & ~RESETg;					// assert RESET, set SELA:B = outputs
					PORTC.DIR = PORTC.DIR | RESETg;
					eewr_nxt(pnew);										// store new bank to EEPROM
					set_bank(pnew);										// assert new bank outputs
					chk_tmr2(RSTWAIT);									// set RSTWAIT delay
					state = RBSTATE1;									// advance state machine (processes RSTWAIT delay)
					rtrn = 1;											// trigger to disable manual inputs
					pttsub_reg = rd_psub();								// fetch saved pttsub mode
					break;
				
				case RBSTATE1:
					if(!chk_tmr2(0)){									// when reset delay expires...
						PORTC_DIR &= ~RESETg;							// release RESET,
//						PORTB.OUT &= ~DPOUT;							// clear DP,
						remote_bank = RMT_IDLE_CMD;						// clear cmd signal
						state = RBSTATE0;								// process complete, return to idle
					}
					break;
			} // end switch()
		} // end if-rmt signal
	} // end if-cmd
	return rtrn;

#else

	return 0;

#endif

}

/////////////////////////////////////
// process_UART() handles the UART command (remote key code) state machine
//	serial I/O drivers are in "serial(.c/.h)"
//	key message capture and pre-processing are in "hm_cmds(.c/.h)"
//
uint8_t process_UART(uint8_t cmd){
volatile static	uint8_t	ustate;		// uart state machine register
				char*	mptr;		// temp pointer
//volatile static	uint8_t	sstate;		// pttsub state (deprecated)
volatile static	uint8_t	mode_ud;	// up/dn mode
volatile static	uint8_t	udmem;		// up/dn mem
volatile		uint8_t	pc;			// portc temp
				uint8_t	i;			// temp

	if(cmd == IPL_CMD){
		ustate = USTATEI;
//		sstate = SSTATE0;
		chk_tmr4(TIMER_CLEAR);
		pcm = (~PORTC.IN) & TXLED;										// init TXLED state memory
	} // end-if
	// process UART state machine:
	switch(ustate){
		case USTATEI:													// initial (or error reset) state
		default:
			ustate = USTATE3;
			init_uart(SBAUD, ENABLE_RXD);								// enable RXD only
			pfx_reg = DMA_NOKEY;										// invalidate rpn register
			chk_tmr3(MS3000);											// set delay
			break;

		case USTATE0:
			// process analog up/dn button hot-swap detect
			if(is_adc_rdy()){
				i =  qual_adc();
				// detect analog DN press mode-change
				if(mode_ud != ANA_UD){
					if(i == IS_DN){
						mode_ud = ANA_UD;
						set_DMA(DMA_MIC_UP);
						set_pulse2();
					}
				}
				if(mode_ud == ANA_UD){
					if(i != udmem){
						udmem = i;
						switch(i){
							case IS_UP:
								set_DMA(DMA_MIC_UP);
								set_pulse2();
								break;
						
							case IS_DN:
								set_DMA(DMA_MIC_DN);
								set_pulse2();
								break;
						
							default:
								clear_pulse();
								break;
						}
					}
				}
			}
			// check for mode change -- process break-received (enables analog u/d)
			i = getstat(1);
			if(mode_ud != ANA_UD){
				if(i & BRK_DET){
					mode_ud = ANA_UD;
				}
			}
			// process serial msg timeout trap
			if(mode_ud != ANA_UD){
				if(!pulse_clear() && !chk_serto(0)){
					clear_pulse();
				}
			}
//			if(sstate == SSTATE0){										// only process UART if there isn't a pttsub cycle in progress
				// process the next incoming cmd msg
				if(gotcr()){											// look for message & copy if present
					mptr = msg_ptr();									// copy msg to the hm_cmd space
					getss(mptr, MSG_BUFF_END-1);
					hm_cmd_get(mptr, NORM_CMD);							// process message into cmd code buffer (hm_cmd space)
				}
				// process the cmd code buffers
				if(exec_cmd(GET_UART)){									// first, process UART cmd (null_str indicates UART is source)
					chk_tmr3(PULSE_DLY);								// set delay
					ustate = USTATE1;
				}
//			} // end if
			if(got_lcl()){												// process lcl cmd if one is present
				if(exec_cmd(GET_LOCAL)){
					chk_tmr3(PULSE_DLY);								// set delay
					ustate = USTATE1;
				}
			}
			break;

		case USTATE1:
			if(!chk_tmr3(0)){											// wait for pulse delay
					clear_pulse();										// clear pulses
					chk_tmr3(PULSE_DLY);								// set dead-band delay
					ustate = USTATE2;
			}
			break;

		case USTATE2:
			if(!chk_tmr3(0)){
					ustate = USTATE0;									// return to start of state machine
			}
			break;

		case USTATE3:
			if(!chk_tmr3(0)){
				ustate = USTATE0;										// return to start of state machine
			}
			if(gotcr()){												// look for message & copy if present
				mptr = msg_ptr();										// copy msg to the hm_cmd space
				getss(mptr, MSG_BUFF_END-1);							// ignore 1st message...
				ustate = USTATE0;										// return to start of state machine
			}
			break;
	}	// end switch
	// PTTsub state machine
	if((pulse_clear()) && (chk_tmr4(0) == 0) && (pttsub_reg)){		// only process pttsub if the keypad is clear
		pc = (~VPORTC_IN) & TXLED;									// pc==1 if LED on
		if(pc != pcm){												// process TXLED state change
			pcm = pc;												// rememeber interim TX state
			if(pttsub_reg == 1){									// if pttsub disabled, ignore TX LED
				set_button(DMA_SMUTE);								// toggle SMUTE
				pttsub_dly();
			}
			if(pttsub_reg == 2){
				set_button(DMA_SUB);								// toggle SUB
				pttsub_dly();

				set_button(DMA_CALL);								// toggle CALL
				pttsub_dly();

				set_button(DMA_SUB);								// toggle SUB
				pttsub_dly();
			}
		pcm = pc;													// this is the one that counts
		}
	}
	return 0;
}
		
/////////////////////////////////////
// process_DIAL() handles the dial auto-pulse feature
//	if TX_LED == 0, toggle SMUTE then repeat when TX_LED == 1
//

void pttsub_dly(void)
{
	uint8_t pc;

	chk_tmr4(MS175);													// set time delay
	while(chk_tmr4(0));													// wait for delay to complete
	clear_pulse();														// release button
	chk_tmr4(MS35);														// set release delay
	while(chk_tmr4(0));													// wait for complete
	pc = (~VPORTC_IN) & TXLED;
	if(pc != pcm){
		pcm = pc;
		chk_tmr4(MS200);												// set t/r delay
		while(chk_tmr4(0));												// wait for complete
	}
	return;
}
/////////////////////////////////////
// process_DIAL() handles the dial auto-pulse feature
//	if TX_LED == 0, toggle SMUTE then repeat when TX_LED == 1
//
uint8_t process_DIAL(uint8_t cmd){

	if(cmd == IPL_CMD){
		dial_togg = 0;
	}else{
		// process dial u/d toggle
		if(dial_togg){
			clear_pulse();												// toggle pulse2
			wait_T(4);
			set_pulse2();			
			wait_T(4);
		} // end if-dial_togg
	} // end if-cmd
	return 0;
}

/////////////////////////////////////
// process_DIMMER() controls PWM based on DIMMER input (valid for MK-III only)
//
#if MARK == 3
uint8_t process_DIMMER(uint8_t cmd){
	uint8_t	pb;					// temps
#define DIM_STATE	0
#define BRT_STATE	0x80
#define THRESH_LOW	8
#define THRESH_HI	20

	if(cmd == IPL_CMD){
		dim_state = DIM_STATE;											// init LED brightness state
		set_pwm(brt_level(READ_EEDIM));									// restore backlight dim level from EEPROM
	}else{
		pb = get_lsadc();
		if(pb){															// if valid data, process
			if((pb < THRESH_LOW) && (dim_state == BRT_STATE)){
				set_pwm(brt_level(READ_EEDIM));							// set DIM (= bright level/4)
				dim_state = DIM_STATE;
			}
			if((pb > THRESH_HI) && (dim_state == DIM_STATE)){
				set_pwm(brt_level(READ_EEBRT));							// set BRT
				dim_state = BRT_STATE;
			}
		}
	} // end if-cmd
	return 0;
}
#endif

/////////////////////////////////////
// process_FACTI() does a fact-init on all 4 banks
//
void process_FACTI(void){
	uint8_t	i;

	clear_pulse();														// key release: clear pulses
	wait_T(MS1000);
	set_DMA(DMA_MW);													// ATTINY holds MW, user holds CHECK
	set_pulse1();
	for(i=0; i<4; i++){
		wait_T(MS75);
		reset_cyc(i);
		do_beep(4);
		wait_T(MS1000);
	}
	return;
}

/////////////////////////////////////
// exec_cmd() executes cmd at sptr
//	if sptr points to a null, get cmd byt from UART stream
//	return 0 if no timed pulse release.  Right now always returns 0
//
uint8_t exec_cmd(uint8_t vect){
	uint8_t	pd;				// temps
	uint8_t	i;
	char	c;

	// process inbound key-cmd string from internal or HM-133
	if(vect == GET_LOCAL){
		c = get_lcl();													// get key-cmd byte from internal stream
	}else{
		c = hm_asc();													// get key-cmd byte from HM-133
	}
	// parse cmd and execute if an internal cmd.  Continue with pd = DMA address (or 0xff if a non-button cmd).
	pd = c;
	if(c != DMA_KREL) c &= ~DMA_KHOLD;
	switch(c){
		default:
//			pfx_reg = DMA_NOKEY;										// clear prefix reg
		case DMA_NOKEY:
		case DMA_KREL:
			break;

		case DMA_0:														// process input to rpn register
		case DMA_1:
		case DMA_2:
		case DMA_3:
		case DMA_4:
		case DMA_5:
		case DMA_6:
		case DMA_7:
		case DMA_8:
		case DMA_9:
			i = c - DMA_0;
			switch(pfx_reg){
			case DMA_BANK:												// process mem-bank select once digit is pressed
				if(i <= 3){
					remote_bank = i | RMT_BANK_CMD;						// queue bank change
					// beep bank#
					if(i){
						do_beep(i);
					}else{
						do_beep_err(1);									// error beep = bank 0
					}
				}else{
					// interrogate bank#
					i = read_bank();
					switch(i){
						default:
						case 0:
						do_beep_err(1);									// error beep = bank 0
						break;

						case 1:
						case 2:
						case 3:
						do_beep(i);
						break;
					}
				}
				pfx_reg = DMA_NOKEY;
				pd = DMA_NOKEY;
				break;

			case DMA_PSUBENT:											// process PTTSUB select mode enter
				if(i <= 2){
					pttsub_reg = i;										// set mode change
					// beep mode#
					if(i){
						do_beep(i);
					}else{
						do_beep_err(1);									// error beep = bank 0
					}
				}else{
					if(i == 9){
						sto_psub(pttsub_reg);							// store mode to eeprom
						do_beep(2);
					}else{
					// interrogate mode#
						switch(pttsub_reg){
						default:
						case 0:
							do_beep_err(1);									// error beep = bank 0
							break;

						case 1:
						case 2:
							do_beep(pttsub_reg);
							break;
						}
					}
				}
				pfx_reg = DMA_NOKEY;
				pd = DMA_NOKEY;
				break;

			case DMA_FACI:
				if(i == 9){												// execute 4-bank factory init
					do_beep(2);
					wait_T(MS2000);
					process_FACTI();
					pd = DMA_NOKEY;
				}else{
					if(i == 1){											// assert LOCK button
						pd = DMA_LOCK;
					}else{
						do_beep_err(1);									// invalid -- do error beep
						pd = DMA_NOKEY;
					}
				}
				pfx_reg = DMA_NOKEY;
				break;

			default:
				do_beep_err(1);											// invalid -- do error beep
				pd = DMA_NOKEY;
				break;
			}
			pfx_reg = DMA_NOKEY;
			break;

		case DMA_RNULL:													// invalidate rpn register
//			pfx_reg = DMA_NOKEY;
			pd = DMA_NOKEY;
			break;

		case DMA_MMUTE:													// main mute - does 25 VOL-DN steps
		case DMA_MMUTE|DMA_KHOLD:
			set_DMA(DMA_VOLDN);											// set DMAddr = vol dn
			for(i=0; i<25; i++){
				set_pulse1();											// pulse voldn
				wait_T(MS35);
				clear_pulse();
				wait_T(MS35);
			}
			pd = DMA_NOKEY;
			pfx_reg = DMA_NOKEY;
			break;

		case DMA_FACI:
		case DMA_PSUBENT:												// process PTTSUB select
		case DMA_BANK:													// process mem-bank select
			do_beep(2);
			pfx_reg = c;
			pd = DMA_NOKEY;
			break;

/*		case DMA_PSUBSVE:										// process PTTSUB select
			i = rpn_reg;
			if(i != RPN_NULL){
				if((i <= 1) && (i >= 0)){
					pttsub_reg = i & PTTSUB_M;
					// response beeps indicate status
					switch(pttsub_reg){
						default:
							pttsub_reg = PTTSUB_MOD0;
						case PTTSUB_MOD0:
						//  	  				do_1beep();
							do_beep(1);
						break;

						case PTTSUB_MOD1:
						//  	  				do_2beep();
							do_beep(2);
						break;

						case PTTSUB_MOD2:
						//  	  				do_3beep();
							do_beep(3);
						break;

//						case PTTSUB_MOD3:
//						//  	  				do_4beep();
//						break;
					}
					sto_psub(pttsub_reg);						// store mode to eeprom
				}
				rpn_reg = RPN_NULL;
			}
			pd = DMA_NOKEY;
			break;*/

//		case DMA_PSUBENT:										// process PTTSUB mode store to eeprom
			// save pttsub_reg to eeprom indexed with bank select to allow a different setting for each bank
//  	  	do_2beep();
//			do_beep(2);
//			break;

		case DMA_TOGP2:													// process toggle dial up/dn
			// need to mechanize enable of the toggling here, the actual toggling needs to happen in one of the state machines
			dial_togg = 1;												// send signal to toggle machine
			pd = DMA_NOKEY;
			break;
	}
	// if a valid keystroke, process press or release function
	if((pd > 0x30) && (pd < 0x40)) pd = DMA_NOKEY;						// pseudo keys are not valid after this point
	set_button(pd);
	return 0;
}

/////////////////////////////////////
// set_button() does press/release of button
//
void set_button(uint8_t bpd){

	if(bpd != DMA_NOKEY){
		if(bpd == DMA_KREL){
			clear_pulse();													// key release: clear pulses
			dial_togg = 0;													// end signal to toggle machine
		}else{
			set_DMA(bpd);													// set DMAddr
			if(bpd & DMA_PULS2){											// set pulse 1 or 2
				set_pulse2();
			}else{
				set_pulse1();
			}
		}
	}
	chk_serto(KEY_TIMOUT);													// reset serial watchdog
	return;
}

/////////////////////////////////////
// set_DMA() sets DMA address
//
void set_DMA(uint8_t addr){
	uint8_t	pd;

	// map logical addr to port pins
	if(addr == DMA_TSQ) pd = 0;
	else pd = (addr & 0x07) << 4;
	if(addr & 0x08) pd |= DMA3;
	PORTA.OUT = (PORTA.OUT & ~(DMA3|DMA2|DMA1|DMA0)) | pd;
	return;
}

/////////////////////////////////////
// set_pulse1() sets PULSE1 output
//
void set_pulse1(void){

	PORTA.OUT |= PULSE1;
	return;
}

/////////////////////////////////////
// clear_pulse() clears PULSE1 & PULSE2 outputs
//
void clear_pulse(void){

	PORTA.OUT &= ~(PULSE1|PULSE2);
	return;
}

/////////////////////////////////////
// pulse_clear() returns true iff PULSE1 & PULSE2 outputs = 0
//
uint8_t pulse_clear(void){
	volatile uint8_t rtn = 0;
	volatile uint8_t i;

	i = PORTA.OUT & (PULSE1|PULSE2);
	if(!i) rtn = 0x1;
	return rtn;
}
/////////////////////////////////////
// set_pulse2() sets PULSE2 output
//
void set_pulse2(void){

	PORTA.OUT |= PULSE2;
	return;
}

/////////////////////////////////////
// set_pwm() sets pwm level
//
void set_pwm(uint8_t pwm){

	TCA0_SINGLE_CMP2 = ((uint16_t)pwm * PWM_PER) / 100;					// update pwm register
	return;
}



/////////////////////////////////////
// init_ports() initializes GPIO
//
void init_ports(void){

	// init GPIO
	PORTA.OUT = 0;
	PORTC.OUT = 0;
	PORTB.OUT = GAn;
#if MARK == 1
	PORTA.DIR = PULSE1|PULSE2;											// use DMA vector to input remote bank select
	PORTA_PIN1CTRL = PORT_PULLUPEN_bm;									// DMA3 pullup
	PORTA_PIN6CTRL = PORT_PULLUPEN_bm;									// DMA2 pullup
	PORTA_PIN5CTRL = PORT_PULLUPEN_bm;									// DMA1 pullup
	PORTA_PIN4CTRL = PORT_PULLUPEN_bm;									// DMA0 pullup
#else
	PORTA.DIR = PULSE1|PULSE2|DMA2|DMA1|DMA0|DMA3;
//	PORTA_set_pin_pull_mode()
#endif

#if MARK == 3
	PORTB.DIR &= ~DIMMER;												// PB2 is DIMMER input for MARK-III
	PORTB_PIN2CTRL = PORT_PULLUPEN_bm;									// enab DIMMER pullup
#endif
	PORTB.DIR = PORTB.DIR | A12o | GAn | PWMOUT;
	PORTC.DIR = RESETg | A11o;
	return;
}

/////////////////////////////////////
// init_lut() initializes LUT
//	LUT1 not used
//	LUT0 (/GA, PB4) produces </DMA3 (PA1)> OR <P23 (PA2)>
//	ERATTA with ATTINY-816: can not link LUTs without connecting linked lut to an output port or
//		using an event link.  The work-around here was to jumper-wire a change to the pinout to
//		get P23 onto a LUT0 input port pin which dis-obviated the need to link the LUTs.
//
void init_lut(void){

	CCL.CTRLA = 0;														// disable CCL
	CCL.LUT0CTRLA = 0;
	CCL.LUT1CTRLA = 0;
	CCL.SEQCTRL0 = 0;													// no sequential logic for YOU!
	CCL.LUT0CTRLB = CCL_INSEL1_IO_gc;									// DMA3 (an output) is IN1 (IN0 is masked)
	CCL.LUT0CTRLC = CCL_INSEL2_IO_gc;									// P23 (an input) is IN2
	CCL.TRUTH0 = 0x51;													// LUT0-OUT = /DMA + P23

	CCL.LUT0CTRLA = CCL_OUTEN_bm | CCL_FILTSEL_1_bm;					// set as pin output, plus filter
	CCL.LUT0CTRLA |= CCL_ENABLE_bm;										// enable LUT0
	CCL.CTRLA = CCL_ENABLE_bm;											// enable CCL
	PORTMUX.CTRLA |= PORTMUX_LUT0_bm;									// set alternate pin mux for LUT0-OUT (nGA = PB4)
	
	return;
}

/////////////////////////////////////
// init_pwm() initializes TCA single-slope PWM on PB5 (WO2)
//	write new compare value using this equation:
//	TCA0_SINGLE_CMP2 = ((<integer percent value> * PWM_PER) / 100);
//
void init_pwm(void){

	TCA0_SINGLE_PER = PWM_PER;											// set base freq for PWM
	TCA0_SINGLE_CTRLA = TCA_SINGLE_ENABLE_bm;							// enable single timer mode
	TCA0_SINGLE_CMP2 = PWM_PCNT_INIT;									// set the PWM compare reg (derived from the percent value desired)
	TCA0_SINGLE_CTRLB = TCA_SINGLE_CMP2EN_bm | 0x03;					// enable compare2 (WO2) and set for 1-slope PWM

	PORTMUX.CTRLC |= PORTMUX_TCA02_bm;									// set alternate pin mux for WO2 (makes PWM output = PB5)
	
	return;
}

/////////////////////////////////////
// put_lcl() stores data to lcl_cmd & handles overflow of buffer
//
void put_lcl(char c){

	lcl_cmd[lcl_head++] = c;											// store to array
	if(lcl_head == MAX_LCL) lcl_head = 0;								// process index rollover
	if(lcl_head == lcl_tail) lcl_tail += 1;								// process buffer overflow (oldest entry lost)
	if(lcl_tail == MAX_LCL) lcl_tail = 0;								// process index rollover
	return;
}

/////////////////////////////////////
// got_lcl() returns true if lcl_cmd has data
//
uint8_t got_lcl(void){
	uint8_t	c = 0;		// temp, default to false

	if(lcl_head != lcl_tail){
		c = 0xff;														// set true response
	}
	return c;
}

/////////////////////////////////////
// get_lcl() returns data from lcl_cmd & handles underflow of buffer
//
char get_lcl(void){
	char	c = '\0';		// temp, default to null

	if(lcl_head != lcl_tail){
		c = lcl_cmd[lcl_tail++];										// pull from array
		if(lcl_tail == MAX_LCL) lcl_tail = 0;							// process index rollover
	}
	return c;
}

/////////////////////////////////////
// full_lcl() returns true if lcl_cmd is full
//
uint8_t full_lcl(void){
	uint8_t	i = lcl_head + 1;											// use faux index to point to next head location

	if(i == MAX_LCL) i = 0;												// process faux index rollover
	if(i == lcl_tail) return 0xff;										// return full = true
	return 0;															// return full = false
}
