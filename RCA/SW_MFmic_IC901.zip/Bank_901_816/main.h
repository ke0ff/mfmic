/********************************************************************
 ************ COPYRIGHT (c) 2022 by ke0ff, Taylor, TX   *************
 *
 *  File name: main.h
 *
 *  Module:    Control
 *
 *  Summary:   This is the header file for the banksw/rdu app.
 *
 *******************************************************************/

/////////////////////////////////////
// conditional compile flags
// !! comment out for production build !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//#define TUNE	1						// enables tune mode - used to tune the wait loop delay
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !! Set conditional build variant !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//#define MARK	1						// Mark-I interface - BT discrete control, 2-bit banksel, DIMMER input   <<<<<< this needs work!!!
//#define MARK	2						// Mark-II interface - serial command protocol, wired (RX only), 2-bit banksel
#define MARK	3						// Mark-III interface - serial command protocol, wired (RX only), 1-bit bankstep, DIMMER input
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


/********************************************************************
 *  File scope declarations revision history:
 *    02-20-22 jmh:  creation date
 *
 *******************************************************************/
#if defined(__DOXYGEN__)
/** \def wdr()
    \ingroup avr_interrupts

    Kicks watchdog timer

    In order to implement atomic access to multi-byte objects,
    consider using the macros from <util/atomic.h>, rather than
    implementing them manually with wdr().
*/
#define wdr()
#else  /* !DOXYGEN */
# define wdr()  __asm__ __volatile__ ("wdr" ::: "memory")
#endif /* DOXYGEN */


//------------------------------------------------------------------------------
// extern defines
//------------------------------------------------------------------------------
// process_xxx() command defines
#define IPL_CMD		0x7f					// Initial Program Load (reset system variables)
#define NORM_CMD	0x00					// normal process

#define TIMER_CLEAR	0xffff				// timer clear cmd
#define SYSCLK		3333333				// Hz

// timer value defines -- This timer lashup has an uncertainty of +1,-0 base-units due to the uncertainty of synchronization with the prescaler in the MCU hardware.
//		Thus, for low timer values (values less than, say, 5) add a unit to cover this.
//#define MS5			(380*2)				// 5ms			// cheesy for-loop timing value 378 was measured and verified in the TUNE build using 20MHz master clock and 3.333MHz processor clock //
#define TIC			5						// #ms per ISR "tic"
#define MS5			((5/TIC) + 1)			// 5ms, plus 1 for the ISR alignment uncertainty
#define MS10		(10/TIC)				// 10ms
#define MS15		(15/TIC)				// 15ms
#define MS20		(20/TIC)				// 20ms
#define MS25		(25/TIC)				// 25ms
#define MS35		(35/TIC)				// 35ms
#define MS50		(50/TIC)				// 50ms
#define MS75		(75/TIC)				// 75ms
#define MS100		(100/TIC)				// 100ms
#define MS200		(200/TIC)				// 200ms
#define MS250		(250/TIC)				// 250ms
#define MS300		(300/TIC)				// 300ms
#define MS450		(450/TIC)				// 450ms
#define MS1000		(1000/TIC)				// 1000ms
#define MS2000		(2000/TIC)				// 2000ms
#define MS3000		(3000/TIC)				// 3000ms
#define MS5000		(5000/TIC)				// 5000ms
#define MS10000		(10000/TIC)				// 10000ms

#define RAMP_RATE	1						// brightness rampup rate
#define GPIOWAIT	MS5						// GPIO output settling time
#define DEBOUNCE	MS15					// ADDR input debounce delay
#define RSTWAIT		MS20					// RESET assertion duration
#define CHNGWAIT	MS450					// change-wait: duration after valid input is detected before updating outputs
#define PULSE_DLY	MS75					// pulse1/2 delay
//#define PULSE_TODLY	MS75					// pulse1/2 delay
#define SMUTE_DLY	MS200					// SMUTE pulse-wait delay
#define SMUTE_DBNC	MS100					// SMUTE debounce delay
#define SMUTE_STRETCH_DLY	MS300			// SMUTE pulse-stretch delay
#define BEEP_ON_TIME	MS35

// single-slope PWM/TimerA defines
#define PWM_PERCENT_DFLT	25
#define PWM_FREQ			5000
#define PWM_PER				(SYSCLK / PWM_FREQ)
#define PWM_PCNT_INIT		((PWM_PERCENT_DFLT * PWM_PER) / 100)
#define DIM_PWM				30
#define RAMP_PWM_0			0					// brightness ramp-up profile
#define RAMP_PWM_1			(DIM_PWM/6)
#define RAMP_PWM_2			(DIM_PWM/2)
#define RAMP_PWM_3			(5*DIM_PWM/6)
#define RAMP_PWM_4			(DIM_PWM)
#define BRT_PWM				70

// Analog U/D defines
#define KEY_TIMOUT	(1000/TIC)			// HM-1xx Keypress data timeout period

// PORTA
// PA0 = UPDI
#define DMA3		0x02				// PA1	(MUX address b3 out, also feeds to the LUT sub-system)
#define P23			0x04				// PA2	(discrete button MUX pulse output)
#define PULSE2		0x08				// PA3	(MUD2 input ...??? do we need this ???)
#define DMA2		0x10				// PA4	(MUX address b2 out)
#define DMA1		0x20				// PA5	(MUX address b1 out)
#define DMA0		0x40				// PA6	(MUX address b0 out)
#define PULSE1		0x80				// PA7	(MUX-mirror pulse output)

// PORTB
#define LSADC		0x01				// PB0	(light sensor ADC in)
#define MUD2		0x02				// PB1	(mic u/d ADC in)
#define A12o		0x04				// PB2	(bank out msb)
#ifdef DEBUG
#define TXDp		0x04				// PB2 = TXD (HST>>TRG)
#endif
#if	MARK == 1
#define SELB		0x04				// PB2  (select input msb)
#endif
#if MARK == 3
#define DIMMER		0x04				// PB2  (dimmer input)
#endif
#define RXDp		0x08				// PB3 = RXD (HST<<TRG)
#define GAn			0x10				// PB4	(LUT0 output)
#define PWMOUT		0x20				// PB5	(drives LED switch for brightness control)

// PORTC
#if	MARK == 1
#define CHECK		0x01				// PC0	(CHECK button output)
#define SELB1		0x01				// PC0	(MARK-I SELB)
#endif
#if	MARK == 2
#define CHECK		0x01				// PC0	(CHECK button output)
#define SEL_STP		0x02				// PC1	(increment bank pulse input)
#endif
#if	MARK == 3
#define A11o		0x01				// PC0	(CHECK button output)
#define BEEP		0x02				// PC1	(increment bank pulse input)
#endif
#define SELA		0x02				// PC1	(MARK-I select input lsb)
#define RESETg		0x04				// PC2	(IC-901 reset output, drive as open collector/gnd)
#define TXLED		0x08				// PC3	(input used for sub-tx feature)

// PTTsub defines
#define PTTSUB_M		0x1
#define PTTSUB_MOD0		0
#define PTTSUB_MOD1		1
#define PTTSUB_MOD2		2
#define PTTSUB_MOD3		3

// RPN defines
#define RPN_NULL	0xff

// DMA is ordinal address, 0x00 - 0x0f.  Hi-bit indicates PULSE2, else address targets PULSE1
// DMA pulse/release flags
#define DMA_PULS2	0x80
#define	DMA_KREL	0xC0				// all bits must match this define to encode release cmd
#define	DMA_KHOLD	0x40				// all bits must match this define to encode release cmd

// PULSE1 cmds
#define DMA_TSQ		0x30				// 0x00 is "null" so we are using 0x30 to indicate DMA address %0000
#define DMA_VOLUP	1
#define DMA_VOLDN	2
#define DMA_TS		3
#define DMA_SET		4
#define DMA_SUB		5
#define	DMA_MW		6
#define DMA_MS		7
#define DMA_HL		8
#define DMA_SQUP	9
#define DMA_SQDN	10
#define DMA_MHZ		11
#define DMA_MODE	12
#define DMA_VM		13
#define DMA_BAND	14
#define DMA_CALL	15

// "phantom" commands (MFmic controls)
#define DMA_0		0x20				// RPN digits (digits in shift mode) for use by the "phantom commands"
#define DMA_1		0x21
#define DMA_2		0x22
#define DMA_3		0x23
#define DMA_4		0x24
#define DMA_5		0x25
#define DMA_6		0x26
#define DMA_7		0x27
#define DMA_8		0x28
#define DMA_9		0x29
#define DMA_RNULL	0x2a				// commands that the RPN register be set to null (invalid)

#define DMA_MMUTE	0x37				// main mute
#define DMA_KNULL	0x38				// null key to trap lost release
#define DMA_TOGP2	0x39				// toggle PULSE2 until release
#define DMA_PSUBENT	0x3a				// PTTSUB enter (from rpn_reg)
#define DMA_FACI	0x3b				// Do fact reset sequence
#define DMA_BANK	0x3c				// Set IC-901 mem bank select from rpn_reg
#define DMA_BRIGHTP	0x3d				// bright backlight up 1 step
#define DMA_BRIGHTM	0x3e				// dim backlight down 1 step
#define DMA_RESET	0x3f				// reset IC-901


// PULSE2 address defines
#define ADR0		0
#define ADR1		4
#define ADR2		2
#define ADR3		6
#define ADR4		1
#define ADR5		5
#define ADR6		3
#define ADR7		7
// PULSE2 cmds
#define DMA_DIAL_UP	(DMA_PULS2 | ADR0)
#define DMA_MIC_DN	(DMA_PULS2 | ADR1)
#define DMA_MIC_UP	(DMA_PULS2 | ADR2)
#define DMA_DIAL_DN	(DMA_PULS2 | ADR3)
#define DMA_SMUTE	(DMA_PULS2 | ADR4)
// ADDR5 is n/c
#define DMA_LOCK	(DMA_PULS2 | ADR6)
#define DMA_CHECK	(DMA_PULS2 | ADR7)

// "no-key" op-code
#define DMA_NOKEY	0x00

////////////////////////////////////////////////////////
// extern Fn defines

void set_pwm(uint8_t pwm);

// end main.h